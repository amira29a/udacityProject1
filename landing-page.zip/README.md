# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.
//
have added bootstrap files to make hamburger menu as instructor said we can use it
as the project need Navigation is built dynamically as an unordered list.
used in the js file 
define variables and created an arrayto select all sections and make a function to unordered list
create funtion called createdlist to create list of links
created for loop to get section name of each section 
create menu list of each section and add in nav menu in the top 
Added class 'active' to section when near top of viewport
added class active and style by adding your-active-class
created for loop for each section,if the section in view port check this class your-active-class id isnot in the section add it ,else removie the class name 



https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect